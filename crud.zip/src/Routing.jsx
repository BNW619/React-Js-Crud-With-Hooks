// import React from "react";
// import { Button } from "react-bootstrap";
// import { Route, Routes, Link } from "react-router-dom";
// import AddUserForm from "./forms/AddUserForm";

// function Routing() {
//   return (
//     <div>
//       <div>
//           <Link to="/AddUserForm">
//             <Button>Add New User</Button>
//           </Link>
//       </div>
//       <Routes>
//         <Route path="/AddUserForm" element={<AddUserForm />} />
//       </Routes>
//     </div>
//   );
// }

// export default Routing;
