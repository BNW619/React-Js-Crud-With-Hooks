import React from 'react'
import { Card } from 'react-bootstrap'

const UserTable = props => (
  
  <Card>
  <Card.Header className='bg-primary text-white'><h2 className='pt-2'>List View Table</h2></Card.Header>
  <Card.Body>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Username</th>        
      <th>age</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      {props.users.length > 0 ? (
        props.users.map(user => (
          <tr key={user.id}>
            <td>{user.name}</td>
            <td>{user.username}</td>
            <td>{user.age}</td>
            <td>{user.date}</td>
            <td>
              <button
                onClick={() => {
                  props.editRow(user)
                }}
                className="button muted-button bg-success text-white me-2 outline-light"
                variant="outline-secondary "
              >
                Edit
              </button>
              <button
                onClick={() => props.deleteUser(user.id)}
                className="button muted-button bg-danger text-white"
              >
                Delete
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={3}>No users</td>
        </tr>
      )}
    </tbody>
  </table>
    
  </Card.Body>
</Card>
)

export default UserTable
