import React, { useState, useEffect } from 'react'
import { Card, Form, Modal } from 'react-bootstrap'

const EditUserForm = props => {
  const [ user, setUser ] = useState(props.currentUser)

  useEffect(
    () => {
      setUser(props.currentUser)
    },
    [ props ]
  )

  const handleInputChange = event => {
    const { name, value } = event.target

    setUser({ ...user, [name]: value })
  }

  return (
    <div className='mb-3'>
      <Card className="shadow-lg">
        <Card.Header>
          <h1 className='text-dark'>Edit user</h1>
 </Card.Header>
          <Card.Header className="bg-primary text-white">
            <form
      onSubmit={event => {
        event.preventDefault()

        props.updateUser(user.id, user)
      }}
      >
            <Form 
            >
              <Modal.Body>
                {" "}
                <Form.Group className="" controlId="exampleForm.ControlInput1">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                  type="text" name="name" value={user.name} onChange={handleInputChange}
                  />
                </Form.Group>
                <Form.Group className="" controlId="exampleForm.ControlInput1">
                  <Form.Label>username</Form.Label>
                  <Form.Control
                     type="text" name="username" value={user.username} onChange={handleInputChange}
                  />
                </Form.Group>
                <Form.Group className="" controlId="exampleForm.ControlInput1">
                  <Form.Label>age</Form.Label>
                  <Form.Control
                   type="text" name="age" value={user.age} onChange={handleInputChange}
                  />
                </Form.Group>
                <Form.Group className="" controlId="exampleForm.ControlInput1">
                  <Form.Label>date</Form.Label>
                  <Form.Control
                    type="text" name="username" value={user.date} onChange={handleInputChange}
                  />
                </Form.Group>
              </Modal.Body>
              <Modal.Footer>
              </Modal.Footer>
        </Form>
        <button className="button muted-button bg-success border- text-white me-3 mt-2">Update user</button>
      <button onClick={() => props.setEditing(false)} className="button muted-button bg-danger text-white mt-2">
        Cancel
      </button>
            </form> 
          </Card.Header>
        </Card>
        
    </div>  
  )
} 

export default EditUserForm
