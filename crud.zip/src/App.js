import React, { useState, Fragment } from "react";
import { Button, Col, Form, Row } from "react-bootstrap";
import EditUserForm from "./forms/EditUserForm";
import UserTable from "./tables/UserTable";
import { Link, Route, Routes } from "react-router-dom";
import AddUserForm from "./forms/AddUserForm";
import Modal from "react-bootstrap/Modal";

const App = (props) => {
  const initialFormState = { id: null, name: "", username: "" };

  // Data
  const [user, setUser] = useState(initialFormState);

  const usersData = [
    { id: 1, name: "Ali", username: "Ali_Raza", age: "55", date: "02/01/2020" },
    {
      id: 2,
      name: "Meer",
      username: "Meer_Taqi_Meer",
      age: "58",
      date: "06/02/2021",
    },
    {
      id: 3,
      name: "Galib",
      username: "Mirza_Galib",
      age: "75",
      date: "06/02/2020",
    },
  ];

  // Setting state
  const [users, setUsers] = useState(usersData);
  const [currentUser, setCurrentUser] = useState(initialFormState);
  const [editing, setEditing] = useState(false);

  const [show, setShow] = useState(false);

  const handleClose = () => {
    setUser(initialFormState);
    setShow(false);
  };

  const handleShow = () => setShow(true);

  // CRUD operations
  const addUser = (user) => {
    user.id = users.length + 1;
    setUsers([...users, user]);
  };

  const deleteUser = (id) => {
    setEditing(false);

    setUsers(users.filter((user) => user.id !== id));
  };

  const updateUser = (id, updatedUser) => {
    setEditing(false);

    setUsers(users.map((user) => (user.id === id ? updatedUser : user)));
  };

  const editRow = (user) => {
    setEditing(true);
    console.log("user ", user);

    setCurrentUser({
      id: user.id,
      name: user.name,
      username: user.username,
      age: user.age,
      date: user.date,
    });
  };
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setUser({ ...user, [name]: value });
  };
  const [validated, setValidated] = useState("");

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    event.preventDefault();
    console.log("jakhsjkdhas", event);
    if (form.checkValidity() !== false) {
      addUser(user);
      event.stopPropagation();
      setCurrentUser(null)
      handleClose();
    } 
    setValidated(true);
  };

  return (
    <Row className="rop-row  ">
      <Col className="d-flex justify-center">
        <div className=" mt-5">
          <h1 className="crud-heading mt-5">CRUD App with Hooks</h1>
          <div className="mt-5">
            <div className="">
              <Link to="/AddUserForm">
                {/* <Button>Add New User</Button> */}
              </Link>
            </div>
            {/* ------model----- */}
            <div>
              <Button variant="outline-primary" onClick={handleShow}>
                Add Information
              </Button>
              <Modal show={show} onHide={handleClose} animation={false} className="bg-dark text-white">
                <Modal.Header closeButton className="bg-primary text-white">
                  <Modal.Title >Input Form</Modal.Title>
                </Modal.Header>
                <Form
                  noValidate
                  validated={validated}
                  className="p-3"
                  onSubmit={handleSubmit}
                  
                >
                  <Modal.Body>
                    {" "}
                    <Form.Group
                      className=""
                      controlId="exampleForm.ControlInput1"
                    >
                      <Form.Label className="text-dark">Name</Form.Label>
                      <Form.Control
                        required
                        type="text"
                        name="name"
                        value={user.name}
                        onChange={handleInputChange}
                        // style={{
                        //   borderColor:
                        //     errors && errors.name ? "#a80000" : "",
                        // }}
                        // ref={register({ required: true })}
                      />
                      {/* {errors && errors.name && (
                        <FieldError message={"This Field is Required"} />
                      )} */}
                    </Form.Group>
                    <Form.Group
                      className=""
                      controlId="exampleForm.ControlInput1"
                    >
                      <Form.Label className="text-dark">username</Form.Label>
                      <Form.Control
                        required
                        type="text"
                        name="username"
                        value={user.username}
                        onChange={handleInputChange}
                      />
                      <Form.Control.Feedback type="invalid">
                        Please choose a username.
                      </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group
                      className=""
                      controlId="exampleForm.ControlInput1"
                    >
                      <Form.Label className="text-dark">Age</Form.Label>
                      <Form.Control
                        required
                        type="age"
                        name="age"
                        value={user.age}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                    <Form.Group
                      className=""
                      controlId="exampleForm.ControlInput1"
                    > 
                      <Form.Label className="text-dark">Date</Form.Label>
                      <Form.Control
                        required
                        type="date"
                        name="date"
                        value={user.date}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                      Close
                    </Button>
                    <button variant="primary" type="submit">
                      Save Changes
                    </button>
                  </Modal.Footer>
                </Form>
              </Modal>
            </div>

            <div>
              <Routes>
                <Route path="/AddUserForm" element={<AddUserForm />} />
              </Routes>
            </div>
            <div></div>
          </div>
          <div className="flex-row">
            <Row>
              <Col>
                <div className="flex-large">
                  {editing ? (
                    <Fragment>
                      <EditUserForm
                        editing={editing}
                        setEditing={setEditing}
                        currentUser={currentUser}
                        updateUser={updateUser}
                      />
                    </Fragment>
                  ) : (
                    <Fragment></Fragment>
                  )}
                </div>
              </Col>
              <Col md={12}>
                <div className="bg-light border">
                  <UserTable
                    users={users}
                    editRow={editRow}
                    deleteUser={deleteUser}
                    className="mt-5 text-primary"
                  />
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </Col>
    </Row>
  );
};
export function FieldError(props) {
  return (
    <div className="error-message-field-generic">
      <p>{props.message ? props.message : Error.SYSTEM_ERROR}</p>
    </div>
  );
}
export default App;
// (event) => {
//   event.preventDefault();
//   handleClose();
//   if (!user.name || !user.username || !user.age || !user.date)
//     return;
//   addUser(user);
//   setUser(initialFormState);
//   validated = { validated };
// }
